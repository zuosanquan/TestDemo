//
//  MineOwnPhotoFirstController.m
//  TestDemo
//
//  Created by camera360 on 16/5/4.
//  Copyright © 2016年 camera360. All rights reserved.
//

#import "MineOwnPhotoFirstController.h"

static NSString * kCollectCellIdentifier = @"kCollectCellIdentifier";

static const CGFloat insetEdge           = 5.0;
//默认每行显示图片个数为4个
static CGFloat       itemPerLine         = 4.0;
//每个item的大小
static CGFloat       itemSizeWidth       = 100.0;


@interface MineOwnPhotoFirstController ()<UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout>

@property(nonatomic, strong) UICollectionView           * collectView;
@property(nonatomic, strong) NSMutableArray<NSData *>   * imageDatas;
@property(nonatomic, strong) UICollectionViewFlowLayout * flowLayout;
@property(nonatomic, assign) NSInteger                  itemsPerLine;


@end

@implementation MineOwnPhotoFirstController

#pragma Mark -- 懒加载
- (NSMutableArray<NSData *> *)imageDatas
{
    if (!_imageDatas) {
        _imageDatas = @[].mutableCopy;
    }
    return _imageDatas;
}

-(UICollectionViewFlowLayout *)flowLayout
{
    if (!_flowLayout) {
        _flowLayout = [[UICollectionViewFlowLayout alloc] init];
        /** 此处配置layout的属性
         ...
         ...
         **/
    }
    return _flowLayout;
}

-(UICollectionView *)collectView
{
    if (!_collectView) {
        _collectView = [[UICollectionView alloc] initWithFrame:[UIScreen mainScreen].bounds collectionViewLayout:self.flowLayout];
        [_collectView registerClass:[UICollectionViewCell class] forCellWithReuseIdentifier:kCollectCellIdentifier];
        _collectView.dataSource = self;
        _collectView.delegate   = self;
    }
    return _collectView;
}


#pragma  Mark -- 布局工作
- (void) initialUI
{
    [self.view addSubview:self.collectView];
}

- (void) initialEvent
{
    [self addObserver:self forKeyPath:@"itemsPerLine" options:NSKeyValueObservingOptionNew context:nil];
}

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialUI];
    [self initialEvent];
    //设置初始数据
    self.itemsPerLine = itemPerLine;
    // Do any additional setup after loading the view.
}

#pragma Mark -- CollectionView Delegate && DataSource

-(NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    return self.imageDatas.count;
}

-(UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewCell * cell = [collectionView dequeueReusableCellWithReuseIdentifier:kCollectCellIdentifier forIndexPath:indexPath];
    return cell;
}

-(void)collectionView:(UICollectionView *)collectionView willDisplayCell:(UICollectionViewCell *)cell forItemAtIndexPath:(NSIndexPath *)indexPath
{
//    设置cellmodel
}

-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section
{
    return UIEdgeInsetsMake(insetEdge, insetEdge, insetEdge, insetEdge);
}

-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath
{
    return CGSizeMake(itemSizeWidth, itemSizeWidth);
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma Mark  -- Event handle, 事件处理
/** 监听自己的itemsPerline属性， 动态确定每行显示的图片个数 **/
-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary<NSString *,id> *)change context:(void *)context
{
    //如果每行显示item个数发生变化， 更新
    //计算每个Item的大小
    CGSize containerSize = self.view.frame.size;
    itemSizeWidth        = containerSize.width / (1.0 *[change[@"new"] integerValue]);
    //刷新视图
    [self.collectView reloadData];
}

@end
