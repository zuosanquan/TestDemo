//
//  SystemPhotosFirstController.m
//  TestDemo
//
//  Created by camera360 on 16/5/4.
//  Copyright © 2016年 camera360. All rights reserved.
//

#import "SystemPhotosFirstController.h"

@interface SystemPhotosFirstController ()<UIImagePickerControllerDelegate,UINavigationControllerDelegate>

@end

@implementation SystemPhotosFirstController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self initialUI];
    // Do any additional setup after loading the view.
}

- (void) initialUI
{
    self.view.backgroundColor = [UIColor whiteColor];
    UIImagePickerController * imgPickerVc = [[UIImagePickerController alloc] init];
    imgPickerVc.view.backgroundColor = [UIColor orangeColor];
    UIImagePickerControllerSourceType sourcheType = UIImagePickerControllerSourceTypeSavedPhotosAlbum;
    imgPickerVc.sourceType = sourcheType;
    imgPickerVc.delegate = self;
    imgPickerVc.allowsEditing = YES;
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
